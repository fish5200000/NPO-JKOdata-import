// 避免重複監聽
if (!window._jkosListenerAdded) {
  window._jkosListenerAdded = true;

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'startExport') {
      runExport();
    }
  });
}

async function runExport() {
  try {
    // 取得總頁數
    // 用 title 屬性取得所有頁碼，取最大值（避免 :last-of-type 選到省略號或箭頭）
    const totalPages = getTotalPages();

    if (!totalPages || totalPages < 1) {
      chrome.runtime.sendMessage({ type: 'error', message: '無法取得頁數，請確認您在正確頁面' });
      return;
    }

    const allData = [];

    // 回到第 1 頁
    const page1Btn = document.querySelector('.ant-pagination-item[title="1"]');
    if (page1Btn) {
      page1Btn.click();
      await wait(2000);
    }

    let lastRowText = '';

    for (let p = 1; p <= totalPages; p++) {
      // 等待資料載入（偵測內容變更）
      let attempts = 0;
      while (attempts < 15) {
        await wait(400);
        const rows = document.querySelectorAll('.ant-table-row');
        if (rows.length > 0) {
          const currentText = rows[0].textContent.trim().substring(0, 50);
          if (p === 1 || currentText !== lastRowText) {
            lastRowText = currentText;
            break;
          }
        }
        attempts++;
      }

      // 抓取當前頁資料
      const pageData = collectPage();
      allData.push(...pageData);

      // 回報進度
      chrome.runtime.sendMessage({
        type: 'progress',
        page: p,
        total: totalPages,
        collected: allData.length
      });

      // 前往下一頁
      if (p < totalPages) {
        const nextBtn = document.querySelector(
          '.ant-pagination-next:not(.ant-pagination-disabled) button'
        );
        if (nextBtn) nextBtn.click();
        else break;
      }
    }

    // 產生並下載 CSV
    downloadCSV(allData);

    chrome.runtime.sendMessage({ type: 'done', total: allData.length });

  } catch (err) {
    chrome.runtime.sendMessage({ type: 'error', message: err.message });
  }
}

function collectPage() {
  const rows = document.querySelectorAll('.ant-table-row');
  const result = [];
  rows.forEach(row => {
    const cells = Array.from(row.querySelectorAll('.ant-table-cell'));
    const arr = cells.map(c => c.textContent.trim());
    // [0]捐款交易編號 [1]街口交易編號 [2]捐款專區
    // [3]扣款時間 [4]扣款金額 [5]交易狀態
    // [6]團體名稱 [7]專案名稱 [8]捐款人姓名 [9]功能
    if (arr[3]) {
      result.push({
        '扣款時間': arr[3] || '',
        '扣款金額': arr[4] || '',
        '專案名稱': arr[7] || '',
        '捐款人姓名': arr[8] || ''
      });
    }
  });
  return result;
}

function downloadCSV(data) {
  const headers = ['扣款時間', '扣款金額', '專案名稱', '捐款人姓名'];

  function esc(val) {
    if (val == null) return '';
    const s = String(val);
    if (/[,"\n「」]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  const rows = [headers.join(',')];
  data.forEach(row => rows.push(headers.map(h => esc(row[h])).join(',')));

  const csv = '\uFEFF' + rows.join('\n'); // BOM for Excel UTF-8
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `街口捐款交易紀錄_${today()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function today() {
  return new Date().toISOString().slice(0, 10).replace(/-/g, '');
}

function getTotalPages() {
  // 從每個分頁 item 的 title 屬性取出頁碼，取最大值
  // 這樣可以正確處理省略號（•••）和箭頭按鈕，不會受 :last-of-type 影響
  const items = document.querySelectorAll('.ant-pagination-item');
  if (!items.length) return 0;
  const pageNums = Array.from(items)
    .map(el => parseInt(el.getAttribute('title') || ''))
    .filter(n => !isNaN(n) && n > 0);
  return pageNums.length ? Math.max(...pageNums) : 0;
}

function wait(ms) {
  return new Promise(r => setTimeout(r, ms));
}