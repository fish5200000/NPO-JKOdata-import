const exportBtn = document.getElementById('exportBtn');
const statusEl = document.getElementById('status');
const progressWrap = document.getElementById('progressWrap');
const progressBar = document.getElementById('progressBar');

function setStatus(msg, type = 'info') {
  statusEl.className = 'status ' + type;
  statusEl.innerHTML = msg;
}

function setProgress(current, total) {
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  progressWrap.style.display = 'block';
  progressBar.style.width = pct + '%';
}

exportBtn.addEventListener('click', async () => {
  exportBtn.disabled = true;
  setStatus('🔍 確認頁面中...', 'info');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url.includes('partner-admin.jkos.com')) {
    setStatus('❌ 請先前往街口後台的<br><strong>單次捐款交易紀錄</strong>頁面', 'error');
    exportBtn.disabled = false;
    return;
  }

  setStatus('⏳ 開始抓取資料，請稍候...', 'info');
  setProgress(0, 1);

  // 注入 content script 並開始執行
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });

  // 發送開始指令
  chrome.tabs.sendMessage(tab.id, { action: 'startExport' });

  // 監聽進度回報
  chrome.runtime.onMessage.addListener(function handler(msg) {
    if (msg.type === 'progress') {
      setStatus(`⏳ 第 ${msg.page} / ${msg.total} 頁，已收集 ${msg.collected} 筆`, 'info');
      setProgress(msg.page, msg.total);
    } else if (msg.type === 'done') {
      setStatus(`✅ 匯出完成！共 <strong>${msg.total} 筆</strong>資料<br>檔案已下載至您的電腦`, 'success');
      setProgress(msg.total, msg.total);
      exportBtn.disabled = false;
      chrome.runtime.onMessage.removeListener(handler);
    } else if (msg.type === 'error') {
      setStatus(`❌ 錯誤：${msg.message}`, 'error');
      exportBtn.disabled = false;
      chrome.runtime.onMessage.removeListener(handler);
    }
  });
});